//
//  image.swift
//  Fun
//
//  Created by MacStudent on 2018-03-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
import UIKit

class image: UICollectionViewCell{
    
    
    @IBOutlet weak var soundimage: UIImageView!
    
    @IBOutlet weak var soundlbl: UILabel!
    
}
